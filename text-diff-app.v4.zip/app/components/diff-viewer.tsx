"use client"

import { useMemo } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { GitCompare, FileText } from "lucide-react"
import type { TextSet } from "../page"

interface DiffViewerProps {
  textSets: TextSet[]
  groupName: string
}

interface DiffResult {
  type: "equal" | "insert" | "delete"
  content: string
}

export function DiffViewer({ textSets, groupName }: DiffViewerProps) {
  const diffResults = useMemo(() => {
    if (textSets.length < 2) return null

    // Simple word-based diff algorithm
    const generateDiff = (text1: string, text2: string): DiffResult[] => {
      const words1 = text1.split(/\s+/)
      const words2 = text2.split(/\s+/)
      const results: DiffResult[] = []

      let i = 0,
        j = 0

      while (i < words1.length || j < words2.length) {
        if (i >= words1.length) {
          // Remaining words in text2 are insertions
          results.push({ type: "insert", content: words2[j] })
          j++
        } else if (j >= words2.length) {
          // Remaining words in text1 are deletions
          results.push({ type: "delete", content: words1[i] })
          i++
        } else if (words1[i] === words2[j]) {
          // Words match
          results.push({ type: "equal", content: words1[i] })
          i++
          j++
        } else {
          // Look ahead to find matches
          let found = false
          for (let k = j + 1; k < Math.min(j + 5, words2.length); k++) {
            if (words1[i] === words2[k]) {
              // Insert words from text2
              for (let l = j; l < k; l++) {
                results.push({ type: "insert", content: words2[l] })
              }
              results.push({ type: "equal", content: words1[i] })
              i++
              j = k + 1
              found = true
              break
            }
          }

          if (!found) {
            for (let k = i + 1; k < Math.min(i + 5, words1.length); k++) {
              if (words1[k] === words2[j]) {
                // Delete words from text1
                for (let l = i; l < k; l++) {
                  results.push({ type: "delete", content: words1[l] })
                }
                results.push({ type: "equal", content: words1[k] })
                i = k + 1
                j++
                found = true
                break
              }
            }
          }

          if (!found) {
            // No match found, treat as substitution
            results.push({ type: "delete", content: words1[i] })
            results.push({ type: "insert", content: words2[j] })
            i++
            j++
          }
        }
      }

      return results
    }

    // Generate pairwise diffs
    const diffs = []
    for (let i = 0; i < textSets.length - 1; i++) {
      for (let j = i + 1; j < textSets.length; j++) {
        diffs.push({
          set1: textSets[i],
          set2: textSets[j],
          diff: generateDiff(textSets[i].content, textSets[j].content),
        })
      }
    }

    return diffs
  }, [textSets])

  if (textSets.length === 0) {
    return (
      <Card className="border-gray-200 shadow-sm dark:border-gray-800 dark:bg-gray-800">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-2 text-gray-900 dark:text-white">
            <GitCompare className="h-5 w-5 text-deepgram-teal" />
            Diff Viewer - {groupName}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-16">
            <GitCompare className="h-16 w-16 text-gray-300 dark:text-gray-600 mx-auto mb-4" />
            <p className="text-gray-500 dark:text-gray-400 text-lg">
              Select text sets from {groupName} to view differences
            </p>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (textSets.length === 1) {
    return (
      <Card className="border-gray-200 shadow-sm dark:border-gray-800 dark:bg-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-gray-900 dark:text-white">
            <FileText className="h-5 w-5 text-deepgram-teal" />
            Text Preview
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Badge
                variant="outline"
                className="border-gray-200 text-gray-600 dark:border-gray-600 dark:text-gray-300"
              >
                {textSets[0].source}
              </Badge>
              <h3 className="font-medium text-gray-900 dark:text-white">{textSets[0].name}</h3>
            </div>
            <div className="p-4 bg-muted rounded-lg dark:bg-gray-700">
              <p className="whitespace-pre-wrap text-sm text-gray-900 dark:text-gray-100">{textSets[0].content}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="border-gray-200 shadow-sm dark:border-gray-800 dark:bg-gray-800">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-gray-900 dark:text-white">
          <GitCompare className="h-5 w-5 text-deepgram-teal" />
          Diff Results
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {diffResults?.map((result, index) => (
            <div key={index} className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Badge
                    variant="outline"
                    className="border-gray-200 text-gray-600 dark:border-gray-600 dark:text-gray-300"
                  >
                    {result.set1.name}
                  </Badge>
                  <span className="text-gray-400 dark:text-gray-500">vs</span>
                  <Badge
                    variant="outline"
                    className="border-gray-200 text-gray-600 dark:border-gray-600 dark:text-gray-300"
                  >
                    {result.set2.name}
                  </Badge>
                </div>
              </div>

              <div className="p-4 bg-white border border-gray-200 rounded-lg dark:bg-gray-700 dark:border-gray-600">
                <div className="text-sm leading-relaxed text-gray-900 dark:text-gray-100">
                  {result.diff.map((part, partIndex) => (
                    <span
                      key={partIndex}
                      className={
                        part.type === "insert"
                          ? "bg-green-100 text-green-800 px-1 py-0.5 rounded dark:bg-green-900/30 dark:text-green-300"
                          : part.type === "delete"
                            ? "bg-red-100 text-red-800 px-1 py-0.5 rounded line-through dark:bg-red-900/30 dark:text-red-300"
                            : ""
                      }
                    >
                      {part.content}
                      {partIndex < result.diff.length - 1 ? " " : ""}
                    </span>
                  ))}
                </div>
              </div>

              <div className="flex gap-4 text-xs text-muted-foreground dark:text-gray-400">
                <span className="flex items-center gap-1">
                  <div className="w-3 h-3 bg-green-200 rounded dark:bg-green-800"></div>
                  Added
                </span>
                <span className="flex items-center gap-1">
                  <div className="w-3 h-3 bg-red-200 rounded dark:bg-red-800"></div>
                  Removed
                </span>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
