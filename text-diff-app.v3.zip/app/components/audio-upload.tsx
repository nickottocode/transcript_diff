"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Upload, Loader2, AlertCircle } from "lucide-react"
import type { TextSet } from "../page"

interface AudioUploadProps {
  onAddTextSet: (textSet: Omit<TextSet, "id" | "timestamp">) => void
}

export function AudioUpload({ onAddTextSet }: AudioUploadProps) {
  const [file, setFile] = useState<File | null>(null)
  const [apiKey, setApiKey] = useState("")
  const [isTranscribing, setIsTranscribing] = useState(false)
  const [error, setError] = useState("")

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0]
    if (selectedFile) {
      setFile(selectedFile)
      setError("")
    }
  }

  const transcribeAudio = async () => {
    if (!file || !apiKey.trim()) {
      setError("Please select a file and enter your Deepgram API key")
      return
    }

    setIsTranscribing(true)
    setError("")

    try {
      const formData = new FormData()
      formData.append("audio", file)

      const response = await fetch("https://api.deepgram.com/v1/listen", {
        method: "POST",
        headers: {
          Authorization: `Token ${apiKey.trim()}`,
        },
        body: formData,
      })

      if (!response.ok) {
        throw new Error(`Deepgram API error: ${response.status} ${response.statusText}`)
      }

      const result = await response.json()
      const transcript = result.results?.channels?.[0]?.alternatives?.[0]?.transcript

      if (!transcript) {
        throw new Error("No transcript found in the response")
      }

      onAddTextSet({
        name: `${file.name} (Transcribed)`,
        content: transcript,
        source: "audio",
      })

      // Reset form
      setFile(null)
      setApiKey("")
      const fileInput = document.getElementById("audio-file") as HTMLInputElement
      if (fileInput) fileInput.value = ""
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to transcribe audio")
    } finally {
      setIsTranscribing(false)
    }
  }

  return (
    <div className="space-y-4">
      <Alert className="border-deepgram-teal/20 bg-deepgram-teal-light dark:border-deepgram-teal/30 dark:bg-deepgram-teal/10">
        <AlertCircle className="h-4 w-4 text-deepgram-teal" />
        <AlertDescription className="text-gray-700 dark:text-gray-200">
          You'll need a Deepgram API key to transcribe audio. Get one at{" "}
          <a
            href="https://console.deepgram.com/"
            target="_blank"
            rel="noopener noreferrer"
            className="text-deepgram-teal underline hover:no-underline font-medium"
          >
            console.deepgram.com
          </a>
        </AlertDescription>
      </Alert>

      <div className="space-y-2">
        <Label htmlFor="api-key" className="dark:text-gray-200">
          Deepgram API Key
        </Label>
        <Input
          id="api-key"
          type="password"
          placeholder="Enter your Deepgram API key"
          value={apiKey}
          onChange={(e) => setApiKey(e.target.value)}
          className="border-gray-200 focus:border-deepgram-teal focus:ring-deepgram-teal dark:border-gray-600 dark:bg-gray-700 dark:text-white dark:placeholder-gray-400"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="audio-file" className="dark:text-gray-200">
          Audio File
        </Label>
        <Input
          id="audio-file"
          type="file"
          accept="audio/*"
          onChange={handleFileChange}
          className="border-gray-200 focus:border-deepgram-teal focus:ring-deepgram-teal dark:border-gray-600 dark:bg-gray-700 dark:text-white file:text-gray-700 dark:file:text-gray-300"
        />
        {file && (
          <p className="text-sm text-muted-foreground dark:text-gray-400">
            Selected: {file.name} ({(file.size / 1024 / 1024).toFixed(2)} MB)
          </p>
        )}
      </div>

      {error && (
        <Alert variant="destructive" className="dark:border-red-800 dark:bg-red-900/20">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription className="dark:text-red-200">{error}</AlertDescription>
        </Alert>
      )}

      <Button
        onClick={transcribeAudio}
        disabled={!file || !apiKey.trim() || isTranscribing}
        className="w-full flex items-center gap-2 bg-deepgram-teal hover:bg-deepgram-teal/90 text-white font-medium disabled:opacity-50"
      >
        {isTranscribing ? (
          <>
            <Loader2 className="h-4 w-4 animate-spin" />
            Transcribing...
          </>
        ) : (
          <>
            <Upload className="h-4 w-4" />
            Transcribe Audio
          </>
        )}
      </Button>
    </div>
  )
}
