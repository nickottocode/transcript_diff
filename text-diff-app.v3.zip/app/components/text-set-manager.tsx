"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Trash2, FileText, Mic } from "lucide-react"
import type { TextSet } from "../page"

interface TextSetManagerProps {
  textSets: TextSet[]
  selectedSets: string[]
  onSelectionChange: (selectedSets: string[]) => void
  onRemoveSet: (id: string) => void
}

export function TextSetManager({ textSets, selectedSets, onSelectionChange, onRemoveSet }: TextSetManagerProps) {
  const handleSelectionChange = (setId: string, checked: boolean) => {
    if (checked) {
      onSelectionChange([...selectedSets, setId])
    } else {
      onSelectionChange(selectedSets.filter((id) => id !== setId))
    }
  }

  const selectAll = () => {
    onSelectionChange(textSets.map((set) => set.id))
  }

  const selectNone = () => {
    onSelectionChange([])
  }

  if (textSets.length === 0) {
    return (
      <Card className="border-gray-200 shadow-sm dark:border-gray-800 dark:bg-gray-800">
        <CardHeader>
          <CardTitle className="text-gray-900 dark:text-white">Text Sets</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-500 dark:text-gray-400 text-center py-12">
            No text sets added yet. Add some text or upload audio files to get started.
          </p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="border-gray-200 shadow-sm dark:border-gray-800 dark:bg-gray-800">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-gray-900 dark:text-white">Text Sets ({textSets.length})</CardTitle>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={selectAll}
              className="border-gray-200 text-gray-600 hover:text-deepgram-teal hover:border-deepgram-teal bg-transparent dark:border-gray-600 dark:text-gray-300 dark:hover:text-deepgram-teal dark:hover:border-deepgram-teal"
            >
              Select All
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={selectNone}
              className="border-gray-200 text-gray-600 hover:text-deepgram-teal hover:border-deepgram-teal bg-transparent dark:border-gray-600 dark:text-gray-300 dark:hover:text-deepgram-teal dark:hover:border-deepgram-teal"
            >
              Select None
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {textSets.map((textSet) => (
            <div
              key={textSet.id}
              className="flex items-start gap-3 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors dark:border-gray-700 dark:hover:bg-gray-700"
            >
              <Checkbox
                id={`set-${textSet.id}`}
                checked={selectedSets.includes(textSet.id)}
                onCheckedChange={(checked) => handleSelectionChange(textSet.id, checked as boolean)}
                className="border-gray-300 data-[state=checked]:bg-deepgram-teal data-[state=checked]:border-deepgram-teal dark:border-gray-600"
              />

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-2">
                  {textSet.source === "manual" ? (
                    <FileText className="h-4 w-4 text-deepgram-teal" />
                  ) : (
                    <Mic className="h-4 w-4 text-green-500" />
                  )}
                  <h4 className="font-medium truncate text-gray-900 dark:text-white">{textSet.name}</h4>
                  <Badge
                    variant="secondary"
                    className="text-xs bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-300"
                  >
                    {textSet.source}
                  </Badge>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-300 line-clamp-2">{textSet.content}</p>
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                  Added {textSet.timestamp.toLocaleString()}
                </p>
              </div>

              <Button
                variant="ghost"
                size="sm"
                onClick={() => onRemoveSet(textSet.id)}
                className="text-gray-400 hover:text-red-500 dark:text-gray-500 dark:hover:text-red-400"
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
